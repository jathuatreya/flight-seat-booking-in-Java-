import java.io.FileWriter;
import java.io.IOException;

public class Ticket {
    private Person person;
    private char rowLetter;
    private int seatNumber;
    private int price;

    //constructors
    public Ticket(Person person, char rowLetter, int seatNumber, int price) {
        this.person = person;
        this.rowLetter = rowLetter;
        this.seatNumber = seatNumber;
        this.price = price;
    }
//getters
    public Person getPerson() {
        return person;
    }

    public char getRowLetter() {
        return rowLetter;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public int getTicketPrice() {
        return price;
    }


    //setters
    public void setName(Person Person) {
        this.person = person;
    }
    public void setRowLetter(char rowLetter) {
        this.rowLetter = rowLetter;
    }
    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }
    public void setTicketprice(int price) {
        this.price = price;
    }
//ticket printing details
    public void printTicketDetails() {
        System.out.println("Row: " + rowLetter);
        System.out.println("Seat Number: " + seatNumber);
        System.out.println("Price: $" + price);
    }


    //saving options
    public void save() {
        String fileName = rowLetter + Integer.toString(seatNumber) + ".txt";
        try (FileWriter file = new FileWriter(fileName)) {
            file.write("Name: " + person.getName() + "\n");
            file.write("Surname: " + person.getSurname() + "\n");
            file.write("Email: " + person.getEmail() + "\n");
            file.write("Row: " + rowLetter + "\n");
            file.write("Seat Number: " + seatNumber + "\n");
            file.write("Price: $" + price + "\n");
            file.flush();
        } catch (IOException e) {
            System.out.println("Error " + fileName);
            e.printStackTrace();
        }
    }


}
