import java.util.Scanner;

public class PlaneManagement {
    //class variables and arrays declarations
    static int [] seats_A = new int[14];
    static int[] seats_B = new int[12];
    static int[] seats_C = new int[12];
    static int[] seats_D = new int[14];
    static int seatPrice;

    static int ticketsCount = 0;
    static Ticket[] ticketsArray = new Ticket[51];

    //main functions
    public static void main(String[] args) {
        displayMenu(); // Main entry point of the program
    }

    // method for display the main menu
    public static void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n\nWelcome to the Plane Management application\n");
        System.out.println("**************************************************");
        System.out.println("*                  MENU OPTIONS                  *");
        System.out.println("**************************************************");
        System.out.println("1) Buy a Seat");
        System.out.println("2) Cancel a Seat");
        System.out.println("3) Find First Available Seat");
        System.out.println("4) Show Seating Plan");
        System.out.println("5) Print Ticket Information and Total Sales");
        System.out.println("6) Search Tickets  ");
        System.out.println("0) Quit");
        System.out.println("**************************************************");

        System.out.print("\nPlease select an option: ");
        int starting_option = scanner.nextInt();
//validation via user input
        if (starting_option == 0) {
            quit(); // Quit the application
        } else if (starting_option == 1) {
            buy_seat(); // Proceed to buy a seat
        } else if (starting_option == 2) {
            cancel_seat(); // Proceed to cancel a seat
        } else if (starting_option == 3) {
            find_first_available(); // Find the first available seat
        } else if (starting_option == 4) {
            show_seating_plan(); // Display the seating plan
        } else if (starting_option == 5) {
            print_tickets_info(); // Print ticket information and total sales
        } else if (starting_option == 6) {
            search_ticket(); // Proceed to search for a ticket
        } else {
            System.out.println("Invalid input");
            askingAgain(); // Ask for valid input
        }
    }

    // Method to ask whether the user wants to continue or quit
    public static void askingAgain() {
        System.out.print("\n");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Do you want to continue? Press 'y' to continue, 'q' to quit: ");
        char input = scanner.next().charAt(0);
        if (input == 'y' || input == 'Y') {
            displayMenu(); // Continue displaying the main menu
        } else if (input == 'q' || input == 'Q') {
            quit(); // Quit the application
        } else {
            System.out.println("Invalid input");
            askingAgain(); // Ask for valid input
        }
    }

    // method for buy seat
    public static void buy_seat() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your name:");
        String name = scanner.next();
        System.out.println("Enter your surname:");
        String surname = scanner.next();
        System.out.println("Enter your email:");
        String email = scanner.next();
        System.out.println("Enter the Row letter 'A' or 'B' or 'C' or 'D': ");
        char rowLetter = scanner.next().charAt(0);

        //converting row letter (char) to array
        int[] indexRow;
        if (rowLetter == 'A' || rowLetter == 'a') {
            indexRow = seats_A;
        } else if (rowLetter == 'B' || rowLetter == 'b') {
            indexRow = seats_B;
        } else if (rowLetter == 'C' || rowLetter == 'c') {
            indexRow = seats_C;
        } else if (rowLetter == 'D' || rowLetter == 'd') {
            indexRow = seats_D;
        } else {
            System.out.println("Invalid row letter.");
            askingAgain();
            return;
        }

        System.out.print("Enter the Seat number (1-14): ");
        int seatNumber = scanner.nextInt() - 1;


        if (seatNumber < 0 || seatNumber >(indexRow.length)) {
            System.out.println("Invalid seat number.");
            askingAgain();

        }
//if seat is available its " 0 " after its change as 0
        if (indexRow[seatNumber] == 0) {
            indexRow[seatNumber] = 1;
//seat price declarations
            if (seatNumber >= 9) {
                seatPrice = 180;
            } else if (seatNumber >= 5) {
                seatPrice = 150;
            } else {
                seatPrice = 200;
            }
            //first save the data on person object on person class
            Person person = new Person(name, surname, email);
            //next for ticket class
            Ticket ticket = new Ticket(person, rowLetter, seatNumber, seatPrice);
            ticketsArray[ticketsCount++] = ticket;
            System.out.println("Seat booked successfully!");
            ticket.save();
        } else {
            System.out.println("Seat is already booked.");
        }

        askingAgain();
    }
    // Method for cancel a seat
    public static void cancel_seat() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your name:");
        String name = scanner.next();
        System.out.println("Enter your surname:");
        String surname = scanner.next();
        System.out.println("Enter your email:");
        String email = scanner.next();
        System.out.println("Enter the Row letter 'A' or 'B' or 'C' or 'D': ");
        char rowLetter = scanner.next().charAt(0);

        int[] indexRow;
        if (rowLetter == 'A' || rowLetter == 'a') {
            indexRow = seats_A;
        } else if (rowLetter == 'B' || rowLetter == 'b') {
            indexRow = seats_B;
        } else if (rowLetter == 'C' || rowLetter == 'c') {
            indexRow = seats_C;
        } else if (rowLetter == 'D' || rowLetter == 'd') {
            indexRow = seats_D;
        } else {
            System.out.println("Invalid row letter.");
            return;
        }

        System.out.print("Enter the Seat number (1-14): ");
        int seatNumber = scanner.nextInt() - 1;

        if (seatNumber < 0 || seatNumber >(indexRow.length)) {
            System.out.println("Invalid seat number.");
            askingAgain();

        }

        if (indexRow[seatNumber] == 1) {
            indexRow[seatNumber] = 0;

            // checking the values if ts same or not
            for (int i = 0; i < ticketsCount; i++) {
                Ticket ticket = ticketsArray[i];
                if (ticket.getPerson().getName().equals(name) &&
                        ticket.getPerson().getSurname().equals(surname) &&
                        ticket.getPerson().getEmail().equals(email) &&
                        ticket.getRowLetter() == rowLetter &&
                        ticket.getSeatNumber() == seatNumber) {
                    // Shift remaining tickets to fill the gap
                    for (int j = i; j < ticketsCount - 1; j++) {
                        ticketsArray[j] = ticketsArray[j + 1];
                    }
                    ticketsCount--;
                    System.out.println("Seat cancelled successfully!");
                    break;
                }
                else{
                    System.out.println("Wrong, Information Doesn't match");
                }


            }
        } else {
            System.out.println("Seat is not booked.");
        }

        askingAgain();
    }

    // Method to find the first available seat
    public static void find_first_available() {
        boolean found = false;
        //check every array and array element bye using for loop
        for (int i = 0; i < seats_A.length; i++) {
            if (seats_A[i] == 0) {
                System.out.println("First seat is available on A row " + (i + 1) + " seat");
                found = true;
                break;
            }
        }
        if (!found) {
            for (int i = 0; i < seats_B.length; i++) {
                if (seats_B[i] == 0) {
                    System.out.println("First seat is available on B row " + (i + 1) + " seat");
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            for (int i = 0; i < seats_C.length; i++) {
                if (seats_C[i] == 0) {
                    System.out.println("First seat is available on C row " + (i + 1) + " seat");
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            for (int i = 0; i < seats_D.length; i++) {
                if (seats_D[i] == 0) {
                    System.out.println("First seat is available on D row " + (i + 1) + " seat");
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            System.out.println("No seat is available");
        }

        askingAgain();
    }

    // Method to display the seating plan
    public static void show_seating_plan() {
        //get every element one by one using for loop and then change to charcetores
        System.out.print("Row A : ");
        for (int j : seats_A) {

            if (j == 0) {
                System.out.print("O ");
            } else {
                System.out.print("X ");
            }
        }
        System.out.println();
        System.out.print("Row B : ");
        for (int j : seats_B) {

            if (j == 0) {
                System.out.print("O ");
            } else {
                System.out.print("X ");
            }
        }
        System.out.println();
        System.out.print("Row C : ");
        for (int j : seats_C) {

            if (j == 0) {
                System.out.print("O ");
            } else {
                System.out.print("X ");
            }
        }
        System.out.println();
        System.out.print("Row D : ");
        for (int j : seats_D) {

            if (j == 0) {
                System.out.print("O ");
            } else {
                System.out.print("X ");
            }
        }
        System.out.println();

        askingAgain();
    }

    // Method to display ticket information and total sales
    public static void print_tickets_info() {
        int total = 0;
        for (int i = 0; i < ticketsCount; i++) {
            Ticket ticket = ticketsArray[i];
            Person person = ticket.getPerson();
            System.out.println("Ticket number  " + (i + 1) + ":");
            person.printPersonDetails();
            ticket.printTicketDetails();
            total += ticket.getTicketPrice();
            System.out.println("----------------------");
        }
        System.out.println("Total $" + total);
        askingAgain();
    }

    // Method to search for a ticket
    public static void search_ticket() {

        Scanner scanner =new Scanner(System.in);
        System.out.println("Enter the Row letter 'A' or 'B' or 'C' or 'D': ");
        char rowLetter = scanner.next().charAt(0);

        int[] indexRow;
        if (rowLetter == 'A' || rowLetter == 'a') {
            indexRow = seats_A;
        } else if (rowLetter == 'B' || rowLetter == 'b') {
            indexRow = seats_B;
        } else if (rowLetter == 'C' || rowLetter == 'c') {
            indexRow = seats_C;
        } else if (rowLetter == 'D' || rowLetter == 'd') {
            indexRow = seats_D;
        } else {
            System.out.println("Invalid row letter.");
            return;
        }

        System.out.print("Enter the Seat number (1-14): ");
        int seatNumber = scanner.nextInt() - 1;


        if (seatNumber < 0 || seatNumber >= indexRow.length) {
            System.out.println("Invalid seat number.");
            return;
        }
//checking row letter and seat number if its already available or not
        if (indexRow[seatNumber] == 1) {
            // Seat is booked
            for (int i = 0; i < ticketsCount; i++) {
                Ticket ticket = ticketsArray[i];
                if (ticket.getRowLetter() == rowLetter  &&  ticket.getSeatNumber() == seatNumber) {
                    // Print Ticket and Person information
                    ticket.getPerson().printPersonDetails();
                    ticket.printTicketDetails();
                    askingAgain();
                }
            }
        } else {
            // Seat is available
            System.out.println("This seat is available.");
        }
        askingAgain();
    }

    // Method to quit the application
    public static void quit() {
        System.out.println("Goodbye!");
        System.exit(0);
    }
}
